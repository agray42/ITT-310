#include <stdio.h>

int main()
{
	int num1, num2, result;
	char op;

	printf("Enter first number: ");
	scanf_s("%d", &num1);

	printf("Choose an operator: + | - | * | / \n");
	scanf_s(" %c", &op);

	printf("Enter second number: ");
	scanf_s("%d", &num2);

	

	if (op == '+')
	{
		result = num1 + num2;
		printf("The total is: %d", num1 + num2);
	}

	else if (op == '-')
	{
		result = num1 - num2;
		printf("The total is: %d", num1 - num2);
	}

	else if (op == '*')
	{
		result = num1 * num2;
		printf("The total is: %d", num1 * num2);

	}

	else if (op == '/')
	{
		result = num1 / num2;
		printf("The total is: %d", num1 / num2);

	}

	else
	{
		printf("Invalild Input");

	}

	



}